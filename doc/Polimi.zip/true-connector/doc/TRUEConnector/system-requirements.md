### System requirements <a href="doc/#systemrequirements" id="systemrequirements"></a>

In order to run TRUE Connector following minimal system requirements are needed:

* CPU core: 1/container
* Memory: 1024MB - for ECC services, 512M for DataApp and Usage Control services

This values can be considered as initial values, and if required, they can be increased or reduces, keeping the functionality of TRUE Connector unchanged.