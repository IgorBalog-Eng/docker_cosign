## REST API <a href="#restapi" id="restapi"></a>

Detailed description of API endpoints provided by TRUE Connector can be found in [link](rest\_api/REST\_API.md)

Bare in mind that all endpoints of the TRUE Connector will require authorization. Please follow [this link](https://github.com/Engineering-Research-and-Development/true-connector-execution\_core\_container/blob/master/doc/SECURITY.md) to get more information about providing correct credentials for desired request/functionality.