## Postman collection <a href="#postman" id="postman"></a>

There is a postman collection which can be used to initiate requests that are most commonly used: perform contract negotiation, get artifact, broker interaction, manipulate Self Description document via API.

![Postman collection](../postman\_collection.png)

[TRUE Connector.postman\_collection](../../TRUEConnector.postman\_collection.json)\


[TRUE Connector enviroment.postman\_environment](../../TRUEConnector\_enviroment.postman\_environment.json)

This collection comes with predefined environments so be sure to also import environment file.
