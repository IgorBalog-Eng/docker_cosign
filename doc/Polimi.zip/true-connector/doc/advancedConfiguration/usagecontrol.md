### Usage Control <a href="#usagecontrol" id="usagecontrol"></a>

Details about the PMP and PEP components and how to switch to PostgeSQL from the default H2 in-memory database you can find [here](../PLATOON\_USAGE\_CONTROL.md).

Since Usage Control is disabled by default, in order to enable it, set following property to true:

```
application.isEnabledUsageControl=true

```
