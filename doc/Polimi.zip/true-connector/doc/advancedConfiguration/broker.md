
### Broker <a href="#broker" id="broker"></a>

Information on how TRUE Connector can interact with Broker, can be found on following [link](https://github.com/Engineering-Research-and-Development/true-connector-execution\_core\_container/blob/master/doc/BROKER.md)
