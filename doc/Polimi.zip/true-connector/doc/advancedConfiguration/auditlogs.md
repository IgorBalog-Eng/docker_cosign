### Audit logs <a href="#auditlogs" id="auditlogs"></a>

Audit logging is turned **off** by default. If you wish to configure it or even turn off please follow this [document](https://github.com/Engineering-Research-and-Development/true-connector-execution\_core\_container/blob/master/doc/AUDIT.md) .
