## Advanced configuration <a href="#advancedconfiguration" id="advancedconfiguration"></a>

If you did not find which property to change by editing **.env** file, there is an option, to modify property file directly, by editing one of the **application-docker.properties** files located in **ecc\_resources\_consumer** or **ecc\_resources\_provider** directories. There are comments present in property files, which describes impact and usage of some of the properties.
