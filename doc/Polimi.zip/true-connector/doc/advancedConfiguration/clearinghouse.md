### Clearing House <a href="#clearinghouse" id="clearinghouse"></a>

The TRUE Connector supports is able to communicate with the Fraunhofer Clearing House for registering transactions.

Since Clearing house is disabled by default, in order to enable it, set following property to true:

```
application.isEnabledClearingHouse=true

```
