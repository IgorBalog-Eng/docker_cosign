### Extended jwt validation <a href="#extendedjwt" id="extendedjwt"></a>

TRUE Connector can check additional claims from jwToken. For more information. please check \[following link] (https://github.com/Engineering-Research-and-Development/true-connector-execution_core_container/blob/41914b4513a05ce16769a56a4ba683641ad44489/doc/TRANSPORTCERTSSHA256.md?plain=1#L2)
