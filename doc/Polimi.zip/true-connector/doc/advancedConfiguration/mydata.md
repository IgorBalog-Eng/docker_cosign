### MyData Usage Control <a href="#mydata" id="mydata"></a>

The TRUE Connector integrates both the [Platoon Usage Control Data App](https://github.com/Engineering-Research-and-Development/true-connector-uc\_data\_app\_platoon) and [MyData Usage Control Data App](https://github.com/Engineering-Research-and-Development/true-connector-uc\_data\_app) for enforcing the Usage Control. True Connector is by default configured to use Platoon Usage Control, in order to use MyData follow the instructions in the [document](../MYDATA\_USAGE\_CONTROL.md).
