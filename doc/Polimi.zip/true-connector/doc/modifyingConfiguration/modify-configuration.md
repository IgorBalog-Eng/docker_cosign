## Modifying configuration <a href="#modifyconfiguration" id="modifyconfiguration"></a>

If you wish to change some configuration parameters for TRUE Connector, it can be done by editing **.env** file.